package net.md_5.bungee.api.chat;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

/**
 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
 */
@java.lang.Deprecated
@Getter
@ToString
@EqualsAndHashCode
@RequiredArgsConstructor
public final class ClickEvent
{

    /**
	 * The type of action to perform on click.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private final Action action;
    /**
	 * Depends on the action.
	 * @see Action
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private final String value;

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public enum Action
    {

        /**
		 * Open a url at the path given by {@link net.md_5.bungee.api.chat.ClickEvent#value} .
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		OPEN_URL,
        /**
		 * Open a file at the path given by {@link net.md_5.bungee.api.chat.ClickEvent#value} .
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		OPEN_FILE,
        /**
		 * Run the command given by {@link net.md_5.bungee.api.chat.ClickEvent#value} .
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		RUN_COMMAND,
        /**
		 * Inserts the string given by {@link net.md_5.bungee.api.chat.ClickEvent#value}  into the player's text box.
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		SUGGEST_COMMAND,
        /**
		 * Change to the page number given by {@link net.md_5.bungee.api.chat.ClickEvent#value}  in a book.
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		CHANGE_PAGE,
        /**
		 * Copy the string given by {@link net.md_5.bungee.api.chat.ClickEvent#value}  into the player's clipboard.
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		COPY_TO_CLIPBOARD
    }
}
