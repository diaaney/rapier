package net.md_5.bungee.chat;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
 */
@java.lang.Deprecated
@Data
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class TranslationRegistry
{

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public static final TranslationRegistry INSTANCE = new TranslationRegistry();
    //
    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private final List<TranslationProvider> providers = new LinkedList<>();

    static
    {
        try
        {
            INSTANCE.addProvider( new JsonProvider( "/assets/minecraft/lang/en_us.json" ) );
        } catch ( Exception ex )
        {
        }

        try
        {
            INSTANCE.addProvider( new JsonProvider( "/mojang-translations/en_us.json" ) );
        } catch ( Exception ex )
        {
        }

        try
        {
            INSTANCE.addProvider( new ResourceBundleProvider( "mojang-translations/en_US" ) );
        } catch ( Exception ex )
        {
        }
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private void addProvider(TranslationProvider provider)
    {
        providers.add( provider );
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public String translate(String s)
    {
        for ( TranslationProvider provider : providers )
        {
            String translation = provider.translate( s );

            if ( translation != null )
            {
                return translation;
            }
        }

        return s;
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private interface TranslationProvider
    {

        /**
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		String translate(String s);
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	@Data
    private static class ResourceBundleProvider implements TranslationProvider
    {

        /**
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		private final ResourceBundle bundle;

        /**
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		public ResourceBundleProvider(String bundlePath)
        {
            this.bundle = ResourceBundle.getBundle( bundlePath );
        }

        /**
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		@Override
        public String translate(String s)
        {
            return ( bundle.containsKey( s ) ) ? bundle.getString( s ) : null;
        }
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	@Data
    @ToString(exclude = "translations")
    private static class JsonProvider implements TranslationProvider
    {

        /**
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		private final Map<String, String> translations = new HashMap<>();

        /**
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		public JsonProvider(String resourcePath) throws IOException
        {
            try ( InputStreamReader rd = new InputStreamReader( JsonProvider.class.getResourceAsStream( resourcePath ), StandardCharsets.UTF_8 ) )
            {
                JsonObject obj = new Gson().fromJson( rd, JsonObject.class );
                for ( Map.Entry<String, JsonElement> entries : obj.entrySet() )
                {
                    translations.put( entries.getKey(), entries.getValue().getAsString() );
                }
            }
        }

        /**
		 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
		 */
        @java.lang.Deprecated
		@Override
        public String translate(String s)
        {
            return translations.get( s );
        }
    }
}
