package net.md_5.bungee.api.chat;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This component processes a target selector into a pre-formatted set of discovered names. <br> Multiple targets may be obtained, and with commas separating each one and a final "and" for the last target. The resulting format cannot be overwritten. This includes all styling from team prefixes, insertions, click events, and hover events. <br> These values are filled in by the server-side implementation. <br> As of 1.12.2, a bug ( MC-56373 ) prevents full usage within hover events.
 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
 */
@java.lang.Deprecated
@Getter
@Setter
@ToString
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public final class SelectorComponent extends BaseComponent
{

    /**
	 * An entity target selector (@p, @a, @r, @e, or @s) and, optionally, selector arguments (e.g. @e[r=10,type=Creeper]).
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private String selector;

    /**
	 * The separator of multiple selected entities. <br> The default is  {@code}  {"color": "gray", "text": ", "}}.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private BaseComponent separator;

    /**
	 * Creates a selector component from the original to clone it.
	 * @param original  the original for the new selector component
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public SelectorComponent(SelectorComponent original)
    {
        super( original );
        setSelector( original.getSelector() );
        setSeparator( original.getSeparator() );
    }

    /**
	 * Creates a selector component from the selector
	 * @param selector  the selector as a String
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public SelectorComponent(String selector)
    {
        setSelector( selector );
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	@Override
    public SelectorComponent duplicate()
    {
        return new SelectorComponent( this );
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	@Override
    protected void toPlainText(StringBuilder builder)
    {
        builder.append( this.selector );
        super.toPlainText( builder );
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	@Override
    protected void toLegacyText(StringBuilder builder)
    {
        addFormat( builder );
        builder.append( this.selector );
        super.toLegacyText( builder );
    }
}
