package net.md_5.bungee.api.chat;

/**
 * An object capable of being translated by the client in a {@link TranslatableComponent} .
 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
 */
@java.lang.Deprecated
public interface TranslationProvider
{

    /**
	 * Get the translation key.
	 * @return  the translation key
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	String getTranslationKey();

    /**
	 * Get this translatable object as a  {@link TranslatableComponent} .
	 * @return  the translatable component
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	default TranslatableComponent asTranslatableComponent()
    {
        return asTranslatableComponent( (Object[]) null );
    }

    /**
	 * Get this translatable object as a  {@link TranslatableComponent} .
	 * @param with  the  {@link String  Strings}  and {@link BaseComponent  BaseComponents}  to use in the translation
	 * @return  the translatable component
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	default TranslatableComponent asTranslatableComponent(Object... with)
    {
        return new TranslatableComponent( this, with );
    }
}
