package net.md_5.bungee.api.chat.hover.content;

import lombok.EqualsAndHashCode;
import lombok.ToString;
import net.md_5.bungee.api.chat.HoverEvent;

/**
 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
 */
@java.lang.Deprecated
@ToString
@EqualsAndHashCode
public abstract class Content
{

    /**
	 * Required action for this content type.
	 * @return  action
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public abstract HoverEvent.Action requiredAction();

    /**
	 * Tests this content against an action
	 * @param input  input to test
	 * @throws UnsupportedOperationException  if action incompatible
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public void assertAction(HoverEvent.Action input) throws UnsupportedOperationException
    {
        if ( input != requiredAction() )
        {
            throw new UnsupportedOperationException( "Action " + input + " not compatible! Expected " + requiredAction() );
        }
    }
}
