package net.md_5.bungee.api.chat;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.md_5.bungee.api.ChatColor;

/**
 * Represents a style that may be applied to a  {@link BaseComponent} .
 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
 */
@java.lang.Deprecated
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public final class ComponentStyle implements Cloneable
{

    /**
	 * The color of this style.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private ChatColor color;
    /**
	 * The font of this style.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private String font;
    /**
	 * Whether this style is bold.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private Boolean bold;
    /**
	 * Whether this style is italic.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private Boolean italic;
    /**
	 * Whether this style is underlined.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private Boolean underlined;
    /**
	 * Whether this style is strikethrough.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private Boolean strikethrough;
    /**
	 * Whether this style is obfuscated.
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	private Boolean obfuscated;

    /**
	 * Returns the color of this style. May return null.
	 * @return  the color of this style, or null if default color
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public ChatColor getColor()
    {
        return color;
    }

    /**
	 * Returns whether or not this style has a color set.
	 * @return  whether a color is set
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public boolean hasColor()
    {
        return ( color != null );
    }

    /**
	 * Returns the font of this style. May return null.
	 * @return  the font of this style, or null if default font
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public String getFont()
    {
        return font;
    }

    /**
	 * Returns whether or not this style has a font set.
	 * @return  whether a font is set
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public boolean hasFont()
    {
        return ( font != null );
    }

    /**
	 * Returns whether this style is bold.
	 * @return  whether the style is bold
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public boolean isBold()
    {
        return ( bold != null ) && bold.booleanValue();
    }

    /**
	 * Returns whether this style is bold. May return null.
	 * @return  whether the style is bold, or null if not set
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public Boolean isBoldRaw()
    {
        return bold;
    }

    /**
	 * Returns whether this style is italic. May return null.
	 * @return  whether the style is italic
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public boolean isItalic()
    {
        return ( italic != null ) && italic.booleanValue();
    }

    /**
	 * Returns whether this style is italic. May return null.
	 * @return  whether the style is italic, or null if not set
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public Boolean isItalicRaw()
    {
        return italic;
    }

    /**
	 * Returns whether this style is underlined.
	 * @return  whether the style is underlined
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public boolean isUnderlined()
    {
        return ( underlined != null ) && underlined.booleanValue();
    }

    /**
	 * Returns whether this style is underlined. May return null.
	 * @return  whether the style is underlined, or null if not set
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public Boolean isUnderlinedRaw()
    {
        return underlined;
    }

    /**
	 * Returns whether this style is strikethrough
	 * @return  whether the style is strikethrough
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public boolean isStrikethrough()
    {
        return ( strikethrough != null ) && strikethrough.booleanValue();
    }

    /**
	 * Returns whether this style is strikethrough. May return null.
	 * @return  whether the style is strikethrough, or null if not set
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public Boolean isStrikethroughRaw()
    {
        return strikethrough;
    }

    /**
	 * Returns whether this style is obfuscated.
	 * @return  whether the style is obfuscated
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public boolean isObfuscated()
    {
        return ( obfuscated != null ) && obfuscated.booleanValue();
    }

    /**
	 * Returns whether this style is obfuscated. May return null.
	 * @return  whether the style is obfuscated, or null if not set
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public Boolean isObfuscatedRaw()
    {
        return obfuscated;
    }

    /**
	 * Returns whether this style has any formatting explicitly set.
	 * @return  true if at least one value is set, false if none are set
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public boolean isEmpty()
    {
        return color != null || font != null || bold != null
                || italic != null || underlined != null
                || strikethrough != null || obfuscated != null;
    }

    /**
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	@Override
    public ComponentStyle clone()
    {
        return new ComponentStyle( color, font, bold, italic, underlined, strikethrough, obfuscated );
    }

    /**
	 * Get a new  {@link ComponentStyleBuilder} .
	 * @return  the builder
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public static ComponentStyleBuilder builder()
    {
        return new ComponentStyleBuilder();
    }

    /**
	 * Get a new  {@link ComponentStyleBuilder}  with values initialized to the style values of the supplied  {@link ComponentStyle} .
	 * @param other  the component style whose values to copy into the builder
	 * @return  the builder
	 * @deprecated BungeeCord Chat API has been deprecated in favor of Adventure API. For help with migrating your code, see <a href="https://docs.advntr.dev/migration/bungeecord-chat-api.html">https://docs.advntr.dev/migration/bungeecord-chat-api.html</a>
	 */
    @java.lang.Deprecated
	public static ComponentStyleBuilder builder(ComponentStyle other)
    {
        return new ComponentStyleBuilder()
                .color( other.color )
                .font( other.font )
                .bold( other.bold )
                .italic( other.italic )
                .underlined( other.underlined )
                .strikethrough( other.strikethrough )
                .obfuscated( other.obfuscated );
    }
}
